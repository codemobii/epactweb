(function() {
var exports = {};
exports.id = 188;
exports.ids = [188,888];
exports.modules = {

/***/ 7544:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(6381)


/***/ }),

/***/ 4701:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ BreadcrumbAddon; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9222);
/* harmony import */ var _chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9701);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1522);
/* harmony import */ var _utils_media_util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2230);







function BreadcrumbAddon({
  title = "",
  links = [],
  image = null
}) {
  const global = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_pages_app__WEBPACK_IMPORTED_MODULE_4__.GlobalContext);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__.Box, {
    w: "100%",
    pos: "relative",
    backgroundImage: image ? (0,_utils_media_util__WEBPACK_IMPORTED_MODULE_5__/* .getStrapiMedia */ .$)(image) : (0,_utils_media_util__WEBPACK_IMPORTED_MODULE_5__/* .getStrapiMedia */ .$)(global.breadcrumb_bg),
    bgSize: "cover",
    bgPos: "center",
    bgRepeat: "no-repeat",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__.Center, {
      w: "100%",
      bgGradient: "linear(to-r, blackAlpha.600, rgba(0,0,0,0.8))",
      color: "white",
      py: "80px",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__.Stack, {
        textAlign: "center",
        align: "center",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__.Heading, {
          textTransform: "capitalize",
          fontSize: "4xl",
          children: title
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__.HStack, {
          children: links.map((e, i) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__.Text, {
              fontSize: "xs",
              children: e
            }, i), links[links.length - 1] !== e && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__.BsChevronRight, {}, i)]
          }, i))
        })]
      })
    })
  });
}

/***/ }),

/***/ 2892:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ MainButton; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5573);
/* harmony import */ var _chakra_ui_button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function MainButton({
  title = "Button",
  onClick = () => {},
  loading = false,
  link = false
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_button__WEBPACK_IMPORTED_MODULE_1__.Button, {
    fontSize: "sm",
    fontWeight: "bold",
    color: "white",
    bg: "green.400",
    href: link ? link : undefined,
    _hover: {
      bg: "green.300"
    },
    _active: {
      bg: "green.500",
      transform: "scale(0.8)"
    },
    px: "50px",
    rounded: "full",
    size: "lg",
    as: link ? "a" : "button",
    onClick: onClick,
    isLoading: loading,
    loadingText: "Loading",
    children: title
  });
}

/***/ }),

/***/ 136:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ BgIllustration; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8851);
/* harmony import */ var _chakra_ui_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function BgIllustration({
  isOpac = true
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_image__WEBPACK_IMPORTED_MODULE_1__.Image, {
    src: "https://static.wixstatic.com/media/3db22c_d17037a7ec4041338cd6841f6d837d4e~mv2.png/v1/fill/w_1145,h_564,al_c,q_90,usm_0.66_1.00_0.01/3db22c_d17037a7ec4041338cd6841f6d837d4e~mv2.webp",
    w: "100%",
    h: "100%",
    pos: "absolute",
    top: "0",
    left: "0",
    objectFit: "cover",
    objectPosition: "center",
    opacity: isOpac ? "0.2" : "1"
  });
}

/***/ }),

/***/ 2447:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ BoxContainer; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9222);
/* harmony import */ var _chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function BoxContainer({
  children
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_layout__WEBPACK_IMPORTED_MODULE_1__.Container, {
    pos: "relative",
    maxW: "container.lg",
    children: children
  });
}

/***/ }),

/***/ 8695:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ MainLayout; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "@chakra-ui/layout"
var layout_ = __webpack_require__(9222);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: external "next/router"
var router_namespaceObject = require("next/router");;
var router_default = /*#__PURE__*/__webpack_require__.n(router_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(3426);
;// CONCATENATED MODULE: external "react-icons/fa"
var fa_namespaceObject = require("react-icons/fa");;
// EXTERNAL MODULE: ./pages/_app.js
var _app = __webpack_require__(1522);
// EXTERNAL MODULE: ./utils/api.util.js
var api_util = __webpack_require__(7751);
// EXTERNAL MODULE: ./utils/media.util.js
var media_util = __webpack_require__(2230);
;// CONCATENATED MODULE: ./components/layouts/footer.layout.js











const ListHeader = ({
  children
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(react_.Text, {
    fontWeight: "500",
    fontSize: "lg",
    mb: 2,
    children: children
  });
};

const SocialButton = ({
  children,
  label,
  href
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.chakra.button, {
    bg: (0,react_.useColorModeValue)("blackAlpha.100", "whiteAlpha.100"),
    rounded: "full",
    w: 8,
    h: 8,
    cursor: "pointer",
    as: "a",
    href: href,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "background 0.3s ease",
    _hover: {
      bg: (0,react_.useColorModeValue)("blackAlpha.200", "whiteAlpha.200")
    },
    target: "_blank",
    children: [/*#__PURE__*/jsx_runtime_.jsx(react_.VisuallyHidden, {
      children: label
    }), children]
  });
};

function FooterLayout() {
  const global = (0,external_react_.useContext)(_app.GlobalContext);
  const {
    0: pages,
    1: setPages
  } = (0,external_react_.useState)([]);
  const {
    0: about,
    1: setAbout
  } = (0,external_react_.useState)("");
  (0,external_react_.useEffect)(async () => {
    (0,api_util/* fetchAPI */.I)("/about-us-card-one").then(res => {
      setAbout(res.description);
    });
    (0,api_util/* fetchAPI */.I)("/pages").then(res => {
      setPages(res);
    });
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Box, {
    width: "100%",
    bg: (0,react_.useColorModeValue)("gray.50", "gray.900"),
    color: (0,react_.useColorModeValue)("gray.700", "gray.200"),
    marginBottom: {
      base: "75px",
      md: 0
    },
    children: [/*#__PURE__*/jsx_runtime_.jsx(react_.Container, {
      as: react_.Stack,
      maxW: "container.lg",
      py: 10,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
        templateColumns: {
          sm: "1fr 1fr",
          md: "2fr 1fr 1fr 1fr"
        },
        spacing: 8,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Stack, {
          align: "flex-start",
          children: [/*#__PURE__*/jsx_runtime_.jsx(ListHeader, {
            children: /*#__PURE__*/jsx_runtime_.jsx(react_.Image, {
              cursor: "pointer",
              src: (0,media_util/* getStrapiMedia */.$)(global.logo),
              w: "100px"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(react_.Text, {
            fontSize: "sm",
            children: about
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Stack, {
          align: "flex-start",
          children: [/*#__PURE__*/jsx_runtime_.jsx(ListHeader, {
            children: "Company"
          }), NAV_ITEMS.map((e, i) => /*#__PURE__*/jsx_runtime_.jsx(react_.Link, {
            href: e.href,
            children: e.label
          }, i))]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Stack, {
          align: "flex-start",
          children: [/*#__PURE__*/jsx_runtime_.jsx(ListHeader, {
            children: "Page"
          }), /*#__PURE__*/jsx_runtime_.jsx(react_.Link, {
            href: `/pages/vendors`,
            children: "Vendors"
          }), pages.map((e, i) => /*#__PURE__*/jsx_runtime_.jsx(react_.Link, {
            href: `/pages/${e.slug}`,
            children: e.title
          }, i))]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Stack, {
          align: "flex-start",
          children: [/*#__PURE__*/jsx_runtime_.jsx(ListHeader, {
            children: "Install App"
          }), /*#__PURE__*/jsx_runtime_.jsx(react_.Image, {
            src: "https://www.reservamesa.cl/wp-content/uploads/2018/01/google-play-badge-e1515710938414-300x95.png",
            w: "150px"
          }), /*#__PURE__*/jsx_runtime_.jsx(react_.Image, {
            src: "https://www.reservamesa.cl/wp-content/uploads/2018/01/appstore_badge.png",
            w: "150px"
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(react_.Image, {
      src: "https://static.wixstatic.com/media/3db22c_f389411affe442c28fe600a606a71656~mv2.png/v1/fill/w_1583,h_142,al_c,q_85,usm_0.66_1.00_0.01/3db22c_f389411affe442c28fe600a606a71656~mv2.webp",
      w: "100%",
      h: "auto",
      opacity: "0.2"
    }), /*#__PURE__*/jsx_runtime_.jsx(react_.Box, {
      color: "white",
      bg: "green.400",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Container, {
        as: react_.Stack,
        maxW: "container.lg",
        py: 4,
        direction: {
          base: "column",
          md: "row"
        },
        spacing: 4,
        justify: {
          md: "space-between"
        },
        align: {
          md: "center"
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(react_.Text, {
          children: global.footer_text
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Stack, {
          direction: "row",
          spacing: 6,
          children: [/*#__PURE__*/jsx_runtime_.jsx(SocialButton, {
            label: "Twitter",
            href: global.twitter,
            children: /*#__PURE__*/jsx_runtime_.jsx(fa_namespaceObject.FaTwitter, {})
          }), /*#__PURE__*/jsx_runtime_.jsx(SocialButton, {
            label: "YouTube",
            href: global.facebook,
            children: /*#__PURE__*/jsx_runtime_.jsx(fa_namespaceObject.FaFacebookSquare, {})
          }), /*#__PURE__*/jsx_runtime_.jsx(SocialButton, {
            label: "Instagram",
            href: global.instagram,
            children: /*#__PURE__*/jsx_runtime_.jsx(fa_namespaceObject.FaInstagramSquare, {})
          })]
        })]
      })
    })]
  });
}
const NAV_ITEMS = [{
  label: "About",
  href: "/about"
}, {
  label: "Services",
  href: "/services"
}, {
  label: "Projects",
  href: "/projects"
}, {
  label: "News",
  href: "/news"
}, {
  label: "FAQs",
  href: "/faqs"
}, {
  label: "Feedback",
  href: "/contact"
}];
// EXTERNAL MODULE: ./components/layouts/container.layout.js
var container_layout = __webpack_require__(2447);
// EXTERNAL MODULE: ./components/buttons/main.button.js
var main_button = __webpack_require__(2892);
// EXTERNAL MODULE: external "react-cookie"
var external_react_cookie_ = __webpack_require__(311);
;// CONCATENATED MODULE: ./components/layouts/header.layout.js












const Links = [{
  label: "About",
  href: "/about"
}, {
  label: "Services",
  href: "/services"
}, {
  label: "Projects",
  href: "/projects"
}, {
  label: "News",
  href: "/news"
}, {
  label: "FAQs",
  href: "/faqs"
}, {
  label: "Feedback",
  href: "/contact"
}];

const NavLink = ({
  children,
  href
}) => /*#__PURE__*/jsx_runtime_.jsx(react_.Link, {
  px: 2,
  py: 1,
  rounded: "md",
  _hover: {
    textDecoration: "none",
    bg: (0,react_.useColorModeValue)("gray.200", "gray.700")
  },
  href: href,
  children: children
});

function MainHeader() {
  const {
    isOpen,
    onOpen,
    onClose
  } = (0,react_.useDisclosure)();
  const router = (0,router_namespaceObject.useRouter)();
  const path = router.pathname;
  const global = (0,external_react_.useContext)(_app.GlobalContext);
  const [cookies, setCookie] = (0,external_react_cookie_.useCookies)(["session"]);
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Box, {
      bg: "white",
      children: [/*#__PURE__*/jsx_runtime_.jsx(container_layout/* default */.Z, {
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Flex, {
          h: "90px",
          alignItems: "center",
          justifyContent: {
            base: "center",
            md: "space-between"
          },
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.HStack, {
            spacing: 8,
            alignItems: "center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "/",
              children: /*#__PURE__*/jsx_runtime_.jsx(react_.Image, {
                cursor: "pointer",
                src: (0,media_util/* getStrapiMedia */.$)(global.logo),
                w: "130px"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(react_.HStack, {
              as: "nav",
              spacing: 4,
              display: {
                base: "none",
                md: "flex"
              },
              children: Links.map(link => /*#__PURE__*/jsx_runtime_.jsx(NavLink, {
                href: link.href,
                children: link.label
              }, link.label))
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(react_.Box, {
            d: {
              base: "none",
              md: "flex"
            },
            children: /*#__PURE__*/jsx_runtime_.jsx(main_button/* default */.Z, {
              link: "/myfarm",
              title: "Start Farming"
            })
          })]
        })
      }), isOpen ? /*#__PURE__*/jsx_runtime_.jsx(react_.Box, {
        pb: 4,
        display: {
          md: "none"
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(react_.Stack, {
          as: "nav",
          spacing: 4,
          children: Links.map(link => /*#__PURE__*/jsx_runtime_.jsx(NavLink, {
            href: link.href,
            children: link.label
          }, link.label))
        })
      }) : null]
    })
  });
}
// EXTERNAL MODULE: external "@chakra-ui/spinner"
var spinner_ = __webpack_require__(1018);
// EXTERNAL MODULE: ./components/helpers/bg_illus.helper.js
var bg_illus_helper = __webpack_require__(136);
;// CONCATENATED MODULE: ./components/layouts/loader.layout.js






function LoaderLayout({
  loading = false
}) {
  return loading && /*#__PURE__*/(0,jsx_runtime_.jsxs)(layout_.Center, {
    pos: "fixed",
    zIndex: "100",
    top: "0",
    left: "0",
    w: "100%",
    h: "100%",
    bg: "gray.700",
    transition: "all 0.3s ease",
    opacity: loading ? "1" : "0",
    children: [/*#__PURE__*/jsx_runtime_.jsx(bg_illus_helper/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(spinner_.Spinner, {
      size: "lg",
      color: "white"
    })]
  });
}
// EXTERNAL MODULE: external "@chakra-ui/button"
var button_ = __webpack_require__(5573);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(9701);
;// CONCATENATED MODULE: ./components/layouts/mainbottom.bar.js








function MainBottombarLayout() {
  const [cookies, setCookie] = (0,external_react_cookie_.useCookies)(["session"]);
  const NAV_LINKS = [{
    label: "Home",
    href: "/",
    icon: /*#__PURE__*/jsx_runtime_.jsx(bs_.BsGrid, {
      size: "20px"
    })
  }, {
    label: "My Farm",
    href: "/myfarm",
    icon: /*#__PURE__*/jsx_runtime_.jsx(bs_.BsBarChart, {
      size: "20px"
    })
  }, {
    label: "News",
    href: "/news",
    icon: /*#__PURE__*/jsx_runtime_.jsx(bs_.BsArrowClockwise, {
      size: "20px"
    })
  }, {
    label: "Feedback",
    href: "/contact",
    icon: /*#__PURE__*/jsx_runtime_.jsx(bs_.BsAppIndicator, {
      size: "18px"
    })
  }];
  return /*#__PURE__*/jsx_runtime_.jsx(layout_.Box, {
    bg: "white",
    borderTop: "1px",
    borderColor: "gray.200",
    w: "100%",
    pos: "fixed",
    bottom: "0",
    left: "0",
    d: {
      base: "block",
      md: "none"
    },
    children: /*#__PURE__*/jsx_runtime_.jsx(layout_.SimpleGrid, {
      columns: 4,
      spacing: "10px",
      w: "100%",
      py: "10px",
      children: NAV_LINKS.map((e, i) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Stack, {
        as: "a",
        href: e.href,
        alignItems: "center",
        textAlign: "center",
        children: [e.icon, /*#__PURE__*/jsx_runtime_.jsx(react_.Text, {
          fontSize: "sm",
          children: e.label
        })]
      }, i))
    })
  });
}
;// CONCATENATED MODULE: ./components/layouts/main.layout.js











function MainLayout({
  children,
  title = "Home",
  fullSeo = {}
}) {
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  router_default().events.on("routeChangeStart", url => {
    console.log(`Loading: ${url}`);
    setLoading(true);
  });
  router_default().events.on("routeChangeComplete", () => setLoading(false));
  router_default().events.on("routeChangeError", () => setLoading(false));
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(layout_.Box, {
    w: "100%",
    minH: "100vh",
    pos: "relative",
    bg: "white",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("title", {
        children: ["ePact :: ", title]
      }), fullSeo.metaTitle && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
          property: "og:title",
          content: fullSeo.metaTitle
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "twitter:title",
          content: fullSeo.metaTitle
        })]
      }), fullSeo.metaDescription && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "description",
          content: fullSeo.metaDescription
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          property: "og:description",
          content: fullSeo.metaDescription
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "twitter:description",
          content: fullSeo.metaDescription
        })]
      }), fullSeo.shareImage && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
          property: "og:image",
          content: fullSeo.shareImage
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "twitter:image",
          content: fullSeo.shareImage
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "image",
          content: fullSeo.shareImage
        })]
      }), fullSeo.article && /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:type",
        content: "article"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "twitter:card",
        content: "summary_large_image"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(LoaderLayout, {
      loading: loading
    }), /*#__PURE__*/jsx_runtime_.jsx(MainHeader, {}), children, /*#__PURE__*/jsx_runtime_.jsx(FooterLayout, {}), /*#__PURE__*/jsx_runtime_.jsx(MainBottombarLayout, {})]
  });
}

/***/ }),

/***/ 6381:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";
var __webpack_unused_export__;


var _interopRequireDefault = __webpack_require__(2426);

__webpack_unused_export__ = true;
__webpack_unused_export__ = Container;
__webpack_unused_export__ = createUrl;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(9297));

var _utils = __webpack_require__(7579);

__webpack_unused_export__ = _utils.AppInitialProps;
__webpack_unused_export__ = _utils.NextWebVitalsMetric;
/**
* `App` component is used for initialize of pages. It allows for overwriting and full control of the `page` initialization.
* This allows for keeping state between navigation, custom error handling, injecting additional data.
*/

async function appGetInitialProps({
  Component,
  ctx
}) {
  const pageProps = await (0, _utils.loadGetInitialProps)(Component, ctx);
  return {
    pageProps
  };
}

class App extends _react.default.Component {
  // Kept here for backwards compatibility.
  // When someone ended App they could call `super.componentDidCatch`.
  // @deprecated This method is no longer needed. Errors are caught at the top level
  componentDidCatch(error, _errorInfo) {
    throw error;
  }

  render() {
    const {
      router,
      Component,
      pageProps,
      __N_SSG,
      __N_SSP
    } = this.props;
    return /*#__PURE__*/_react.default.createElement(Component, Object.assign({}, pageProps, // we don't add the legacy URL prop if it's using non-legacy
    // methods like getStaticProps and getServerSideProps
    !(__N_SSG || __N_SSP) ? {
      url: createUrl(router)
    } : {}));
  }

}

exports.default = App;
App.origGetInitialProps = appGetInitialProps;
App.getInitialProps = appGetInitialProps;
let warnContainer;
let warnUrl;

if (false) {} // @deprecated noop for now until removal


function Container(p) {
  if (false) {}
  return p.children;
}

function createUrl(router) {
  // This is to make sure we don't references the router object at call time
  const {
    pathname,
    asPath,
    query
  } = router;
  return {
    get query() {
      if (false) {}
      return query;
    },

    get pathname() {
      if (false) {}
      return pathname;
    },

    get asPath() {
      if (false) {}
      return asPath;
    },

    back: () => {
      if (false) {}
      router.back();
    },
    push: (url, as) => {
      if (false) {}
      return router.push(url, as);
    },
    pushTo: (href, as) => {
      if (false) {}
      const pushRoute = as ? href : '';
      const pushUrl = as || href;
      return router.push(pushRoute, pushUrl);
    },
    replace: (url, as) => {
      if (false) {}
      return router.replace(url, as);
    },
    replaceTo: (href, as) => {
      if (false) {}
      const replaceRoute = as ? href : '';
      const replaceUrl = as || href;
      return router.replace(replaceRoute, replaceUrl);
    }
  };
}

/***/ }),

/***/ 1522:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GlobalContext": function() { return /* binding */ GlobalContext; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3426);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7544);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(311);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_cookie__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_media_util__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2230);
/* harmony import */ var _utils_api_util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7751);




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








 // Store Strapi Global object in context

const GlobalContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_4__.createContext)({});

const MyApp = ({
  Component,
  pageProps
}) => {
  const {
    global
  } = pageProps;
  const theme = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.extendTheme)({
    fonts: {
      heading: "'Inter', sans-serif",
      body: "'Inter', sans-serif"
    }
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
        rel: "shortcut icon",
        href: (0,_utils_media_util__WEBPACK_IMPORTED_MODULE_6__/* .getStrapiMedia */ .$)(global.favIcon)
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(GlobalContext.Provider, {
      value: global,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ChakraProvider, {
        theme: theme,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_cookie__WEBPACK_IMPORTED_MODULE_5__.CookiesProvider, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, _objectSpread({}, pageProps))
        })
      })
    })]
  });
}; // getInitialProps disables automatic static optimization for pages that don't
// have getStaticProps. So article, category and home pages still get SSG.
// Hopefully we can replace this with getStaticProps once this issue is fixed:
// https://github.com/vercel/next.js/discussions/10949


MyApp.getInitialProps = async (ctx, req) => {
  // Calls page's `getInitialProps` and fills `appProps.pageProps`
  const appProps = await next_app__WEBPACK_IMPORTED_MODULE_2__.default.getInitialProps(ctx); // Fetch global site settings from Strapi

  const global = await (0,_utils_api_util__WEBPACK_IMPORTED_MODULE_7__/* .fetchAPI */ .I)("/website-settings"); // Pass the data to our page via props

  return _objectSpread(_objectSpread({}, appProps), {}, {
    pageProps: {
      global
    }
  });
};

/* harmony default export */ __webpack_exports__["default"] = (MyApp);

/***/ }),

/***/ 7150:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Faqs; },
  "getStaticProps": function() { return /* binding */ getStaticProps; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./addons/breadcrumb.addon.js
var breadcrumb_addon = __webpack_require__(4701);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(3426);
// EXTERNAL MODULE: ./components/layouts/container.layout.js
var container_layout = __webpack_require__(2447);
;// CONCATENATED MODULE: ./addons/faqs.addon.js





function FaqsAddon({
  data = []
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(react_.Box, {
    py: "80px",
    children: /*#__PURE__*/jsx_runtime_.jsx(container_layout/* default */.Z, {
      children: /*#__PURE__*/jsx_runtime_.jsx(react_.Accordion, {
        defaultIndex: [0],
        allowMultiple: true,
        children: data.map((e, i) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.AccordionItem, {
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.AccordionButton, {
              children: [/*#__PURE__*/jsx_runtime_.jsx(react_.Box, {
                flex: "1",
                textAlign: "left",
                fontSize: "xl",
                children: e.question
              }), /*#__PURE__*/jsx_runtime_.jsx(react_.AccordionIcon, {})]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(react_.AccordionPanel, {
            pb: 4,
            children: e.answer
          })]
        }, i))
      })
    })
  });
}
// EXTERNAL MODULE: ./components/layouts/main.layout.js + 6 modules
var main_layout = __webpack_require__(8695);
// EXTERNAL MODULE: ./utils/api.util.js
var api_util = __webpack_require__(7751);
;// CONCATENATED MODULE: ./pages/faqs.js







function Faqs({
  faqs
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(main_layout/* default */.Z, {
    title: "FAQs",
    children: [/*#__PURE__*/jsx_runtime_.jsx(breadcrumb_addon/* default */.Z, {
      title: "Frequently Asked Questions",
      links: ["Home", "FAQs"]
    }), /*#__PURE__*/jsx_runtime_.jsx(FaqsAddon, {
      data: faqs
    })]
  });
}
async function getStaticProps() {
  // Run API calls in parallel
  const [faqs] = await Promise.all([(0,api_util/* fetchAPI */.I)("/faqs")]);
  return {
    props: {
      faqs
    },
    revalidate: 1
  };
}

/***/ }),

/***/ 7751:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": function() { return /* binding */ getStrapiURL; },
/* harmony export */   "I": function() { return /* binding */ fetchAPI; }
/* harmony export */ });
function getStrapiURL(path = "") {
  return `${"https://epact-api.herokuapp.com" || 0}${path}`;
} // Helper to make GET requests to Strapi

async function fetchAPI(path) {
  const requestUrl = getStrapiURL(path);
  const response = await fetch(requestUrl);
  const data = await response.json();
  return data;
}

/***/ }),

/***/ 2230:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": function() { return /* binding */ getStrapiMedia; }
/* harmony export */ });
/* harmony import */ var _api_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7751);

function getStrapiMedia(media) {
  const imageUrl = media.url.startsWith("/") ? (0,_api_util__WEBPACK_IMPORTED_MODULE_0__/* .getStrapiURL */ .p)(media.url) : media.url;
  return imageUrl;
}

/***/ }),

/***/ 2426:
/***/ (function(module) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ 5573:
/***/ (function(module) {

"use strict";
module.exports = require("@chakra-ui/button");;

/***/ }),

/***/ 8851:
/***/ (function(module) {

"use strict";
module.exports = require("@chakra-ui/image");;

/***/ }),

/***/ 9222:
/***/ (function(module) {

"use strict";
module.exports = require("@chakra-ui/layout");;

/***/ }),

/***/ 3426:
/***/ (function(module) {

"use strict";
module.exports = require("@chakra-ui/react");;

/***/ }),

/***/ 1018:
/***/ (function(module) {

"use strict";
module.exports = require("@chakra-ui/spinner");;

/***/ }),

/***/ 7579:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/utils.js");;

/***/ }),

/***/ 701:
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 311:
/***/ (function(module) {

"use strict";
module.exports = require("react-cookie");;

/***/ }),

/***/ 9701:
/***/ (function(module) {

"use strict";
module.exports = require("react-icons/bs");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(7150));
module.exports = __webpack_exports__;

})();